/* global wpcAdmin, jQuery */
(function ($) {
    'use strict';

    var rowIndex   = 0;
    var currentGroup = '';

    // ── Init ──────────────────────────────────────────────────────────────────

    $(function () {
        rowIndex = $('#wpc-specs-tbody .wpc-spec-row').length;

        var $groupSelect = $('#wpc_spec_group');
        currentGroup = $groupSelect.val();

        // Show/hide new-key area and specs area based on current value at load
        if (currentGroup) {
            $('#wpc-new-key-area').show();
            $('#wpc-specs-area').show();
        }

        $groupSelect.on('change', function () {
            currentGroup = $(this).val();
            if (!currentGroup) {
                $('#wpc-specs-area').hide();
                $('#wpc-new-key-area').hide();
                return;
            }
            // Fetch keys for newly selected group and rebuild table fresh
            fetchAndRebuildTable(currentGroup);
            $('#wpc-new-key-area').show();
        });

        // ── Add row at bottom ──
        $(document).on('click', '#wpc-add-row', function () {
            if (!currentGroup) return;
            addRowAtEnd(getCurrentKeys());
        });

        // ── Add row AFTER a specific row (+ button) ──
        $(document).on('click', '.wpc-add-row-after', function () {
            if (!currentGroup) return;
            var $currentRow = $(this).closest('tr');
            addRowAfter($currentRow, getCurrentKeys());
        });

        // ── Delete row ──
        $(document).on('click', '.wpc-del-row', function () {
            var $tbody = $('#wpc-specs-tbody');
            // Keep at least 1 row
            if ($tbody.find('.wpc-spec-row').length <= 1) {
                alert('At least one row is required.');
                return;
            }
            $(this).closest('tr').remove();
            reindexRows();
        });

        // ── Add new key to group ──
        $('#wpc_add_new_key').on('click', function () {
            var key = $('#wpc_new_key_input').val().trim();
            if (!key) { alert(wpcAdmin.i18n.enterKeyFirst); return; }
            addKeyToGroup(currentGroup, key);
        });

        $('#wpc_new_key_input').on('keypress', function (e) {
            if (e.which === 13) { e.preventDefault(); $('#wpc_add_new_key').trigger('click'); }
        });
    });

    // ── Fetch keys and rebuild table (group change) ───────────────────────────

    function fetchAndRebuildTable(group) {
        $.post(wpcAdmin.ajaxUrl, {
            action: 'wpc_get_keys',
            nonce:  wpcAdmin.nonce,
            group:  group,
        }, function (res) {
            if (!res.success) return;
            var $tbody = $('#wpc-specs-tbody');
            $tbody.empty();
            rowIndex = 0;
            addRowAtEnd(res.data);
            $('#wpc-specs-area').show();
        });
    }

    // ── Build a new <tr> from template ───────────────────────────────────────

    function buildRow(keys, selectedKey, selectedVal) {
        var idx = rowIndex++;
        var $row = $($('#wpc-row-template').html().replace(/__IDX__/g, idx));
        $row.find('.wpc-key-select').html(buildOptions(keys, selectedKey));
        if (selectedVal !== undefined) {
            $row.find('input[type=text]').val(selectedVal);
        }
        return $row;
    }

    function addRowAtEnd(keys, selectedKey, selectedVal) {
        $('#wpc-specs-tbody').append(buildRow(keys, selectedKey, selectedVal));
    }

    function addRowAfter($refRow, keys) {
        var $newRow = buildRow(keys);
        $refRow.after($newRow);
        reindexRows();
        $newRow.find('.wpc-key-select').focus();
    }

    // ── Build <option> list ───────────────────────────────────────────────────

    function buildOptions(keys, selected) {
        var html = '<option value="">' + wpcAdmin.i18n.selectKey + '</option>';
        $.each(keys, function (i, key) {
            html += '<option value="' + escAttr(key) + '"'
                  + (selected === key ? ' selected' : '') + '>'
                  + escHtml(key) + '</option>';
        });
        return html;
    }

    // ── Re-index all rows after insert/delete ─────────────────────────────────

    function reindexRows() {
        $('#wpc-specs-tbody .wpc-spec-row').each(function (i) {
            $(this).find('select.wpc-key-select').attr('name', 'wpc_specs[' + i + '][key]');
            $(this).find('input[type=text]').attr('name', 'wpc_specs[' + i + '][value]');
            // readonly input (orphaned key) also needs reindex
            $(this).find('input.wpc-key-readonly').attr('name', 'wpc_specs[' + i + '][key]');
        });
        rowIndex = $('#wpc-specs-tbody .wpc-spec-row').length;
    }

    // ── Get current keys from selected group option ───────────────────────────

    function getCurrentKeys() {
        var keys = [];
        var raw = $('#wpc_spec_group option:selected').data('keys');
        if (raw) {
            try {
                var parsed = (typeof raw === 'string') ? JSON.parse(raw) : raw;
                if (Array.isArray(parsed)) return parsed;
            } catch(e) {}
        }
        // Fallback: collect from existing selects
        $('#wpc-specs-tbody .wpc-key-select option').each(function () {
            var v = $(this).val();
            if (v && keys.indexOf(v) === -1) keys.push(v);
        });
        return keys;
    }

    // ── AJAX: add new key to group ────────────────────────────────────────────

    function addKeyToGroup(group, key) {
        var $msg = $('#wpc_new_key_msg');
        $.post(wpcAdmin.ajaxUrl, {
            action: 'wpc_add_new_key',
            nonce:  wpcAdmin.nonce,
            group:  group,
            key:    key,
        }, function (res) {
            if (!res.success) {
                $msg.text(res.data).css('color','red').show();
                return;
            }
            var newKeys = res.data.keys;

            // Refresh all existing key selects
            $('#wpc-specs-tbody .wpc-key-select').each(function () {
                var cur = $(this).val();
                $(this).html(buildOptions(newKeys, cur));
            });

            // Update data-keys cache on option
            $('#wpc_spec_group option[value="' + group + '"]').data('keys', newKeys);

            // Add new row after last with new key pre-selected
            addRowAtEnd(newKeys, key);

            $('#wpc_new_key_input').val('');
            $msg.text(wpcAdmin.i18n.keyAdded).css('color','green').show();
            setTimeout(function () { $msg.fadeOut(); }, 2000);
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    function escHtml(str) { return $('<div>').text(str).html(); }
    function escAttr(str) { return String(str).replace(/"/g, '&quot;'); }

})(jQuery);
